package com.hhh.tilaswebmanagement.mapper;

import com.hhh.tilaswebmanagement.pojo.Emp;
import com.hhh.tilaswebmanagement.pojo.EmpQueryParm;
import org.apache.ibatis.annotations.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Mapper
public interface EmpMapper {
    //原始分页实现
//    @Select("select count(*) from emp e left join dept d on e.dept_id = d.id;")
//    public Long count();
//    @Select("select e.*,d.name deptName from emp e left join dept d on e.dept_id = d.id order" +
//            "" + " by e.update_time desc limit #{start},#{pagesize}")
//    public List<Emp> list(Integer start,Integer pagesize);
//    @Select("select e.*,d.name deptName from emp e left join dept d on e.dept_id = d.id order" +
//            "" + " by e.update_time desc")
//    public List<Emp> list( String name ,
//                           Integer gender,
//                           LocalDate begin,
//                          LocalDate end);
    public List<Emp> list(EmpQueryParm empQueryParm);
    @Options(useGeneratedKeys = true,keyColumn = "id")
    @Insert("insert into emp(username, name, gender, phone, job, salary, image, entry_date, dept_id, create_time, update_time)" +
            "        values (#{username},#{name},#{gender},#{phone},#{job},#{salary},#{image},#{entryDate},#{deptId},#{createTime},#{updateTime})")
    void insert(Emp emp);

    void deleteByIds(List<Integer> ids);

    Emp getById(Integer id);

    void updateById(Emp emp);

    @MapKey("pos")
    List<Map<String,Object>> countEmpJobData();
}
