package com.hhh.tilaswebmanagement.service;

import com.hhh.tilaswebmanagement.pojo.JobOption;

public interface ReportService {
    /*
    统计员工职位人数
     */
    JobOption getEmpJobData();
}
