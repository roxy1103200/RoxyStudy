package com.itheima.Interceptor;

import com.itheima.utils.JwtUtils;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Slf4j
@Component
public class TokenInterceptor implements HandlerInterceptor {
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

    String requestURI = request.getRequestURI();
    // 判断是否是登录请求 路径含有login则放行
        if (requestURI.contains("/login")){
        log.info("登录请求: 放行");
        return true;
    }
    String token = request.getHeader("token");

        if (token == null || token.isEmpty()){
        log.info("令牌为空, 401");
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        return false;
    }

        try {
        JwtUtils.parseToken(token);
    } catch (Exception e) {
        log.info("令牌解析失败, 401");
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        return false;
    }
        log.info("登录请求: 放行");
        return true;
    }
}
