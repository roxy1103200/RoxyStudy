package com.itheima.aop;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Slf4j
@Component
@Aspect
public class MyAspect6 {

    @Before("execution(* com.itheima.service.*.*(..))")
    public void before(JoinPoint joinPoint){
        Object target = joinPoint.getTarget();
        log.info("获取目标对象:{}",target);

        String classname = joinPoint.getTarget().getClass().getName();
        log.info("获取目标类:{}",classname);

        String methodName = joinPoint.getSignature().getName();
        log.info("获取目标方法:{}",methodName);

        Object[] args = joinPoint.getArgs();
        log.info("获取目标方法参数:{}", Arrays.toString( args));
    }

    @Around("execution(* com.itheima.service.*.*(..))")
    public Object around(ProceedingJoinPoint pjp) throws Throwable {
        log.info("around...before");

        Object result = pjp.proceed();

        log.info("around...after");
        return result;
    }
    //后置通知
}
