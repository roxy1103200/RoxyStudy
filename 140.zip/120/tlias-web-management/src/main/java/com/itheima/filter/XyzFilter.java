package com.itheima.filter;

import jakarta.servlet.*;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;

//@WebFilter(urlPatterns = "/*")
@Slf4j
public class XyzFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        Filter.super.init(filterConfig);
        log.info("初始化DemoFile");
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        log.info("DemoFile执行了...拦截请求");
        filterChain.doFilter(servletRequest, servletResponse);
        log.info("DemoFile执行了...放行后");
    }

    @Override
    public void destroy() {
        Filter.super.destroy();
        log.info("销毁DemoFile");
    }
}
