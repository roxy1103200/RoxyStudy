package com.itheima.filter;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;

@WebFilter(urlPatterns = "/*")
@Slf4j
public class DemoFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        Filter.super.init(filterConfig);
        log.info("初始化DemoFilter");
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        log.info("DemoFilter执行了...拦截请求");
        filterChain.doFilter(servletRequest, servletResponse);
        log.info("DemoFilter执行了...放行后");
    }

    @Override
    public void destroy() {
        Filter.super.destroy();
        log.info("销毁DemoFilter");
    }
}
