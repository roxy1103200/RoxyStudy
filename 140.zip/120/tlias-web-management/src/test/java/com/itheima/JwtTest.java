package com.itheima;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.junit.jupiter.api.Test;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class JwtTest {

    @Test
    public void testGenerateJwt(){
        Map<String, Object> dataMap = new HashMap<>();
        dataMap.put("id", 1);
        dataMap.put("username", "hhh");
        String jwt = Jwts.builder().signWith(SignatureAlgorithm.HS256, "aGho")
                .addClaims(dataMap)
                .setExpiration(new Date(System.currentTimeMillis()+3600*1000))
                .compact();
        System.out.println(jwt);
    }
    @Test
    public void testParseJwt(){
        String token = "eyJhbGciOiJIUzI1NiJ9.eyJpZCI6MSwidXNlcm5hbWUiOiJoaGgiLCJleHAiOjE3NzM4MDQ4NDR9.qtABuMA7zb1R7Uit8sXKq99yMBr37DC9u0dsnQjjBQY";
        Claims claims = Jwts.parser().setSigningKey("aGho")
                .parseClaimsJws(token)
                .getBody();
        System.out.println("解析成功" + claims);



    }

}
