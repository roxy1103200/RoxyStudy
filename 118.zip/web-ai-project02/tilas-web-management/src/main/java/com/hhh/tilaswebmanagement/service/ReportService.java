package com.hhh.tilaswebmanagement.service;

import com.hhh.tilaswebmanagement.pojo.JobOption;

import java.util.List;
import java.util.Map;

public interface ReportService {
    /*
    统计员工职位人数
     */
    JobOption getEmpJobData();

    List<Map<String, Object>> getEmpGenderData();
}
