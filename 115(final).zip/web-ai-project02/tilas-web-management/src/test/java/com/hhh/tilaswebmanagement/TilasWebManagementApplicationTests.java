package com.hhh.tilaswebmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TilasWebManagementApplicationTests {

    @Test
    void contextLoads() {
    }

}
