package com.hhh.tilaswebmanagement.controller;

import com.hhh.tilaswebmanagement.pojo.Dept;
import com.hhh.tilaswebmanagement.pojo.Result;
import com.hhh.tilaswebmanagement.service.DeptService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.annotations.Update;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RequestMapping("/depts")
@RestController
public class DeptController {
//  private static final Logger log = LoggerFactory.getLogger(DeptController.class);
//
    @Autowired
    private DeptService deptService;

    //@RequestMapping(value = "/depts" ,method = RequestMethod.GET)
    @GetMapping
    public Result list(){
        log.info("查询全部数据");
        List<Dept> deptList = deptService.findAll();
        return Result.success(deptList);
    }
//    @DeleteMapping("/depts")
//    public Result delete(@RequestParam(value = "id",required = false) Integer deptId){
//        System.out.println("根据id删除数据"+deptId);
//        return Result.success();
//    }
    @DeleteMapping
    public Result delete(Integer id){
        log.info("根据id删除数据 {}",id);
        deptService.deleteById(id);
        return Result.success();
    }

    @PostMapping
    public Result add(@RequestBody Dept dept){
        log.info("添加数据{}",dept);
        deptService.add(dept);
        return Result.success();
    }

    @GetMapping("/{id}")
    public Result getInfo(@PathVariable Integer id){
        log.info("查询数据{}",id);
        Dept dept = deptService.getById(id);
        return Result.success(dept);
    }

    @PutMapping
    public Result update(@RequestBody Dept dept){
        log.info("更新数据{}",dept);
        deptService.update(dept);
        return Result.success();
    }
}
