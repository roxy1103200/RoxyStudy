package com.hhh.tilaswebmanagement.controller;

import com.hhh.tilaswebmanagement.pojo.Emp;
import com.hhh.tilaswebmanagement.pojo.EmpQueryParm;
import com.hhh.tilaswebmanagement.pojo.PageResult;
import com.hhh.tilaswebmanagement.pojo.Result;
import com.hhh.tilaswebmanagement.service.EmpService;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.annotations.Update;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RequestMapping("/emps")
@Slf4j
@RestController
public class EmpController {
    @Autowired
    private EmpService empService;
//    @GetMapping
//    public Result page(@RequestParam(defaultValue = "1") Integer page,
//                       @RequestParam(defaultValue = "10") Integer pagesize,
//                       String name, Integer gender,
//                       @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate begin,
//                       @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate end){
//        log.info("分页查询,参数:{},{},{},{},{},{}",page,pagesize,name,gender,begin,end);
//        PageResult<Emp> pageResult =  empService.page(page,pagesize,name,gender,begin,end);
//        return Result.success(pageResult);
//    }
@GetMapping
public Result page(EmpQueryParm empQueryParm){
    log.info("分页查询,参数:{}",empQueryParm);
    PageResult<Emp> pageResult =  empService.page(empQueryParm);
    return Result.success(pageResult);
}
    @PostMapping
    public Result save(@RequestBody Emp  emp) throws Exception {
        log.info("新增员工:{}",emp);
        empService.save(emp);
        return Result.success();
    }
    //使用数组接受到ids参数然后批量删除
//    @DeleteMapping
//    public Result delete(Integer[] ids){
//        log.info("删除员工:{}", Arrays.toString(ids));
//        return Result.success();
//    }
    @DeleteMapping
    public Result delete(@RequestParam List<Integer> ids){
        log.info("删除员工:{}", ids);
        empService.delete(ids);
        return Result.success();
    }

    @GetMapping("/{id}")
    public Result getInfo(@PathVariable Integer id){
        log.info("查询数据{}",id);
        Emp emp = empService.getInfo(id);
        return Result.success(emp);
    }
    @PutMapping
    public Result update(@RequestBody Emp emp){
        log.info("更新数据{}",emp);
        empService.update(emp);
        return Result.success();
    }
}
