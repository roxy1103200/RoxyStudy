package com.hhh.tilaswebmanagement.service;

import com.hhh.tilaswebmanagement.pojo.Emp;
import com.hhh.tilaswebmanagement.pojo.EmpQueryParm;
import com.hhh.tilaswebmanagement.pojo.PageResult;

import java.time.LocalDate;
import java.util.List;

public interface EmpService {
    PageResult<Emp> page(EmpQueryParm empQueryParm);

//新增员工
    void save(Emp emp) throws Exception;

//删除员工
    void delete(List<Integer> ids);

//查询员工
    Emp getInfo(Integer id);

//修改员工
    void update(Emp emp);
//    PageResult<Emp> page(Integer page, Integer pagesize, String name, Integer gender, LocalDate begin, LocalDate end);
}
