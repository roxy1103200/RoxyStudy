package com.hhh.tilaswebmanagement.service;

import com.hhh.tilaswebmanagement.pojo.Dept;

import java.util.List;

public interface DeptService {
    List<Dept> findAll();

    void deleteById(Integer id);

    //添加
    void add(Dept dept);

    Dept getById(Integer id);

    void update(Dept dept);
}