package com.hhh.tilaswebmanagement.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.hhh.tilaswebmanagement.mapper.EmpExprMapper;
import com.hhh.tilaswebmanagement.mapper.EmpMapper;
import com.hhh.tilaswebmanagement.pojo.*;
import com.hhh.tilaswebmanagement.service.EmpLogService;
import com.hhh.tilaswebmanagement.service.EmpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.lang.reflect.Array;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

@Service
public class EmpServiceImpl implements EmpService {
    @Autowired
    private final EmpMapper empMapper;
    @Autowired
    private EmpExprMapper empExprMapper;
    @Autowired
    private EmpLogService empLogService;

    public EmpServiceImpl(EmpMapper empMapper) {
        this.empMapper = empMapper;
    }

    //    @Autowired
//    private EmpMapper empMapper;
//    @Override
//    public PageResult<Emp> page(Integer page, Integer pagesize) {
//        Long total = empMapper.count();
//
//        Integer start = (page-1)*pagesize;
//
//        List<Emp> rows = empMapper.list(start, pagesize);
//        //调用mapper接口接受记录数
//        return new PageResult<Emp>(total,rows);
//    }
//    @Override
//    public PageResult<Emp> page(Integer page, Integer pagesize, String name, Integer gender, LocalDate begin, LocalDate end) {
//        //设置分页参数
//        PageHelper.startPage(page,pagesize);
//
//        List<Emp> empList = empMapper.list(name,gender,begin,end);
//
//        Page<Emp> p = (Page<Emp>) empList;
//        return new PageResult<Emp>(p.getTotal(),p.getResult());
//    }

    @Override
    public PageResult<Emp> page(EmpQueryParm empQueryParm) {
        //设置分页参数
        PageHelper.startPage(empQueryParm.getPage(),empQueryParm.getPageSize());

        List<Emp> empList = empMapper.list(empQueryParm);

        Page<Emp> p = (Page<Emp>) empList;
        return new PageResult<Emp>(p.getTotal(),p.getResult());
    }
    @Transactional(rollbackFor = {Exception.class})//事务管理
    @Override
    public void save(Emp emp) throws Exception {
        try {
            emp.setCreateTime(LocalDateTime.now());
            emp.setUpdateTime(LocalDateTime.now());
            empMapper.insert(emp);

//            int i = 1/0;

            List<EmpExpr> exprList = emp.getExprList();
            if (!CollectionUtils.isEmpty(exprList)){
                exprList.forEach(empExpr-> {
                    empExpr.setEmpId(emp.getId());
                });
                empExprMapper.insertBatch(exprList);
            }
        } finally {
            EmpLog empLog = new EmpLog(null, LocalDateTime.now(), "新增员工"+ emp);
            empLogService.insertLog(empLog);
        }

    }

    @Transactional(rollbackFor = {Exception.class})
    @Override
    public void delete(List<Integer> ids) {
        empMapper.deleteByIds(ids);

        empExprMapper.deleteByEmpIds(ids);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void update(Emp emp) {
        emp.setUpdateTime(LocalDateTime.now());
        empMapper.updateById(emp);

        empExprMapper.deleteByEmpIds(Arrays.asList(emp.getId()));

        List<EmpExpr> exprList = emp.getExprList();
        if (!CollectionUtils.isEmpty(exprList)){
            exprList.forEach(empExpr-> empExpr.setEmpId(emp.getId()));
            empExprMapper.insertBatch(exprList);
        }
    }

    @Override
    public Emp getInfo(Integer id) {
        return empMapper.getById(id);
    }

}
