package com.hhh.tilaswebmanagement.service;

import com.hhh.tilaswebmanagement.pojo.EmpLog;

public interface EmpLogService {

    public void insertLog(EmpLog empLog);

}
